﻿using System;
using System.Collections.Generic;

namespace Lab_4_10_04_2022.Northwind
{
    public partial class CurrentProductList
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = null!;
    }
}
