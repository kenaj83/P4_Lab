﻿using System;
using System.Collections.Generic;

namespace Lab_4_10_04_2022.Northwind
{
    public partial class OrderSubtotal
    {
        public int OrderId { get; set; }
        public decimal? Subtotal { get; set; }
    }
}
