﻿using System;
using System.Collections.Generic;

namespace Lab_4_10_04_2022.Northwind
{
    public partial class CategorySalesFor1997
    {
        public string CategoryName { get; set; } = null!;
        public decimal? CategorySales { get; set; }
    }
}
